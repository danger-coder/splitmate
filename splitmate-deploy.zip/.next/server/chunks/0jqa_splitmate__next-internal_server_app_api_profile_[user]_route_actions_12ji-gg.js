module.exports=[74356,(e,o,d)=>{}];

//# sourceMappingURL=0jqa_splitmate__next-internal_server_app_api_profile_%5Buser%5D_route_actions_12ji-gg.js.map