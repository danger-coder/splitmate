module.exports=[32793,(a,b,c)=>{}];

//# sourceMappingURL=0jqa_splitmate__next-internal_server_app__global-error_page_actions_0p.y~u2.js.map