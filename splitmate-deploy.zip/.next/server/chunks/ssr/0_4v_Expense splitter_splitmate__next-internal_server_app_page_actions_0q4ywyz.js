module.exports=[10744,(a,b,c)=>{}];

//# sourceMappingURL=0_4v_Expense%20splitter_splitmate__next-internal_server_app_page_actions_0q4ywyz.js.map