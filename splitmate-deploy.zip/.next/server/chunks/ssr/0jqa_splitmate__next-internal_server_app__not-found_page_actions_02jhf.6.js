module.exports=[9864,(a,b,c)=>{}];

//# sourceMappingURL=0jqa_splitmate__next-internal_server_app__not-found_page_actions_02jhf.6.js.map