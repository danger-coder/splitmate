module.exports=[47383,(a,b,c)=>{}];

//# sourceMappingURL=0jqa_splitmate__next-internal_server_app_analytics_page_actions_0.w5.j5.js.map