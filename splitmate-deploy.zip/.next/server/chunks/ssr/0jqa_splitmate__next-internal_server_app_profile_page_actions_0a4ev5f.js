module.exports=[13470,(a,b,c)=>{}];

//# sourceMappingURL=0jqa_splitmate__next-internal_server_app_profile_page_actions_0a4ev5f.js.map