module.exports=[88128,(e,o,d)=>{}];

//# sourceMappingURL=0jqa_splitmate__next-internal_server_app_api_settlements_route_actions_0-wyqis.js.map