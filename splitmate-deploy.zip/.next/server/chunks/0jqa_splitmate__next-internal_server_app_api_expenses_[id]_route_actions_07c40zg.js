module.exports=[35916,(e,o,d)=>{}];

//# sourceMappingURL=0jqa_splitmate__next-internal_server_app_api_expenses_%5Bid%5D_route_actions_07c40zg.js.map