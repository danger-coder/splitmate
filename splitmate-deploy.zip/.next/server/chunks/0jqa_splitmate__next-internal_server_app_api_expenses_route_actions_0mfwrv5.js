module.exports=[89343,(e,o,d)=>{}];

//# sourceMappingURL=0jqa_splitmate__next-internal_server_app_api_expenses_route_actions_0mfwrv5.js.map