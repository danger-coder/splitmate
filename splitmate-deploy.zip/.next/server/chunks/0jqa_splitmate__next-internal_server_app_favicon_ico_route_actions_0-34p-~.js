module.exports=[7616,(e,o,d)=>{}];

//# sourceMappingURL=0jqa_splitmate__next-internal_server_app_favicon_ico_route_actions_0-34p-~.js.map