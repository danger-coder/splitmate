var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/[root-of-the-server]__0y1ovle._.js")
R.c("server/chunks/00rw_next_dist_esm_build_templates_app-route_0agipiy.js")
R.c("server/chunks/0jqa_splitmate__next-internal_server_app_favicon_ico_route_actions_0-34p-~.js")
R.m(37852)
module.exports=R.m(37852).exports
