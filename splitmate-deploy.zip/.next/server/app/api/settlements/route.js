var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/settlements/route.js")
R.c("server/chunks/[root-of-the-server]__04x1rgj._.js")
R.c("server/chunks/[root-of-the-server]__0y1ovle._.js")
R.c("server/chunks/0jqa_splitmate__next-internal_server_app_api_settlements_route_actions_0-wyqis.js")
R.m(5444)
module.exports=R.m(5444).exports
