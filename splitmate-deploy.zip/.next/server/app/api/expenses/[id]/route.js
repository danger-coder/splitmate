var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/expenses/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0l1mue5._.js")
R.c("server/chunks/[root-of-the-server]__0y1ovle._.js")
R.c("server/chunks/0jqa_splitmate__next-internal_server_app_api_expenses_[id]_route_actions_07c40zg.js")
R.m(2659)
module.exports=R.m(2659).exports
