var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/expenses/route.js")
R.c("server/chunks/[root-of-the-server]__0xc_.cz._.js")
R.c("server/chunks/[root-of-the-server]__0y1ovle._.js")
R.c("server/chunks/0jqa_splitmate__next-internal_server_app_api_expenses_route_actions_0mfwrv5.js")
R.m(40764)
module.exports=R.m(40764).exports
