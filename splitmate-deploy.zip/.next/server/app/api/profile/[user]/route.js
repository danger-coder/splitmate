var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/profile/[user]/route.js")
R.c("server/chunks/[root-of-the-server]__08oak6_._.js")
R.c("server/chunks/[root-of-the-server]__0y1ovle._.js")
R.c("server/chunks/0jqa_splitmate__next-internal_server_app_api_profile_[user]_route_actions_12ji-gg.js")
R.m(40410)
module.exports=R.m(40410).exports
