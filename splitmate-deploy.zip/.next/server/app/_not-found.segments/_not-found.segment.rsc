1:"$Sreact.fragment"
2:I[16599,["/_next/static/chunks/0pjxk3cv6_o~7.js","/_next/static/chunks/0drl1d1ox75r-.js"],"default"]
3:I[65315,["/_next/static/chunks/0pjxk3cv6_o~7.js","/_next/static/chunks/0drl1d1ox75r-.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"lH-uSDl92_etmwbV3TblA"}
