globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/lH-uSDl92_etmwbV3TblA/_buildManifest.js",
    "static/lH-uSDl92_etmwbV3TblA/_ssgManifest.js",
    "static/lH-uSDl92_etmwbV3TblA/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/17xwu6g726v~f.js",
    "static/chunks/0_fg4r3r-0vik.js",
    "static/chunks/03j8f0f--s~~j.js",
    "static/chunks/04552e44.ff4..js",
    "static/chunks/turbopack-053b3ig_cr3dr.js"
  ]
};
